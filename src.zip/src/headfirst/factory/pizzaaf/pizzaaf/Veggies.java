package headfirst.factory.pizzaaf.pizzaaf;

public interface Veggies {
	public String toString();
}
