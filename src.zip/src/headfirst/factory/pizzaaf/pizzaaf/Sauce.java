package headfirst.factory.pizzaaf.pizzaaf;

public interface Sauce {
	public String toString();
}
