package headfirst.factory.pizzaaf.pizzaaf;

public class Spinach implements Veggies {

	public String toString() {
		return "Spinach";
	}
}
