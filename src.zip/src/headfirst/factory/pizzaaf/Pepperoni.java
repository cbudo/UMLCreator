package headfirst.factory.pizzaaf.pizzaaf;

public interface Pepperoni {
	public String toString();
}
