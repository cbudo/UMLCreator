package headfirst.factory.pizzaaf.pizzaaf;

public interface Cheese {
	public String toString();
}
