package headfirst.factory.pizzaaf.pizzaaf;

public interface Clams {
	public String toString();
}
