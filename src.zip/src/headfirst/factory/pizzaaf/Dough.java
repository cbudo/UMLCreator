package headfirst.factory.pizzaaf.pizzaaf;

public interface Dough {
	public String toString();
}
