package headfirst.factory.pizzaaf.pizzaaf;

public class Mushroom implements Veggies {

	public String toString() {
		return "Mushrooms";
	}
}
