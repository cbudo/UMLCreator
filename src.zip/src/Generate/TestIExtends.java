package Generate;

import Parse.IDataStorage;

/**
 * Created by budocf on 1/6/2016.
 */
public interface TestIExtends extends Runnable, IDataStorage {
}
