package pizzafactory.factory.pizzaaf;

public interface Dough {
	public String toString();
}
