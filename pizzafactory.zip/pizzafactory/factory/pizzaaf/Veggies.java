package pizzafactory.factory.pizzaaf;

public interface Veggies {
	public String toString();
}
