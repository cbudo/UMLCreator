package pizzafactory.factory.pizzaaf;

public interface Pepperoni {
	public String toString();
}
