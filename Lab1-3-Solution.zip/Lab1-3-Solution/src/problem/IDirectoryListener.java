package problem;

public interface IDirectoryListener {
	public void directoryChanged(DirectoryEvent e);
}
