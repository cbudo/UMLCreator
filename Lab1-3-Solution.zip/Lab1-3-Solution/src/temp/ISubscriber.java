package temp;

public interface ISubscriber {
	public void handleChange(IWeatherData d);
}
